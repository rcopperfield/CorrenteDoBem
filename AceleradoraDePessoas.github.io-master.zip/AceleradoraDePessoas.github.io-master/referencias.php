<?php

require('header.php');

?>

<div class="container marketing" style="padding-top: 70px;">

    <h3 class="featurette-heading" style="padding-top: 60px; padding-bottom: 40px;" id="referencias">
        
         Outras iniciativas para se conhecer. 
    </h3>
        

    <p> <a href="http://fi.co" > <b> The Founder Institute: </b></a> </p>
 
    <p> <a href="http://fi.co" > <b> The Founder Institute: </b></a> </p>
     
    <p> <a href="http://agenciarj.org/" > <b> Agência de Redes para Juventude: </b></a> </p>
 
</div>


<?php

require('footer.php');

?>

