<?php require "header.php"; ?>

 <div class="container marketing" style="padding-top: 70px;">

  <h2 class="featurette-heading" style="padding-top: 60px; padding-bottom: 40px;" id="About">Transparência Total.   </span></h2>

<p> Conheça todas as transações financeiras de nossa organização. Saiba para onde vai cada centavo arrecadado. </p>

<hr class="featurette-divider">

  <h2 class="featurette-heading" style="padding-top: 60px; padding-bottom: 40px;" id="About">Resumo Consolidado   </span></h2>

<p> Baixe aqui o resumo das transações, no relatório mensal consolidado </P>    

<a href="#" > Mês Fevereiro (quando estiver pronto) </a>

<hr class="featurette-divider">

<h2 class="featurette-heading" style="padding-top: 60px; padding-bottom: 40px;" id="About">Transações Detalhadas.   </span></h2>

<p> Se você quiser auditar todas nossas receitas e despesas. </p>

 <iframe width="100%" src="https://docs.google.com/spreadsheets/d/1O2KzwVjv22R2d9ZfjZ0PXMvpAPfbTEUwwe2kNQ2Kf2w/pubhtml?widget=true&amp;headers=false"></iframe>
         