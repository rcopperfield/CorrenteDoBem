<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

require('header.php');
?>

<div class="container marketing" style="padding-top: 70px;">

    <h2 class="featurette-heading" style="padding-top: 60px; padding-bottom: 40px;" id="About">
        
        Muito Obrigado. 
        
        Registraremos sua doação e mandaremos um email quando for possível de ser auditável por você... Audite as contas <a href="transparencia.php" > aqui </a></h2>

</div>

<?php
require('footer.php');
?>